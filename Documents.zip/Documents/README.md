# TP-CMS
## 使用ThinkPHP做的一个简单的CMS系统

> 运行环境：PHP 5.4及以上  
> 框架版本: ThinkPHP 3.2  
> 数据库运行SQL：/hipo_sequelize_local_db.sql；先执行该SQL才可以把项目运行起来  
> 管理员密码重置：localhost//admin.php?c=login&a=resetpwd 访问该路径就可以把admin的密码重置为123  

### 后台管理
<img src='https://codeyoyo.github.io/TP-CMS/Public/images/admin.png' />

### 前台页面
<img src='https://codeyoyo.github.io/TP-CMS/Public/images/home.png' />
