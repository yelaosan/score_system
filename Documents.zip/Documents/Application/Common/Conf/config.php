<?php
return array(
	'URL_CASE_INSENSITIVE'=>TRUE,//URL地址不区分大小写
	'URL_MODEL'=>0,
	'LOAD_EXT_CONFIG'=>'db',//数据库配置文件
	'MD5_PRE'=>'tp_cms',//MD5加密前缀
	'HTML_FILE_SUFFIX'=>'.html',
	'HTML_CACHE_ON'=>false, // 开启关闭静态缓存
	'DB_SQL_BUILD_CACHE' => false//SQL解析缓存
);
?>