<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TP-CMS后台管理平台</title>
    <link href="/Public/css/weui.min.css" rel="stylesheet">

    <link href="/Public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Public/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="/Public/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/Public/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/css/sing/common.css" />
    <link rel="stylesheet" href="/Public/css/party/bootstrap-switch.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/party/uploadify.css">

    <!-- jQuery -->
    <script src="/Public/js/jquery.js"></script>
    <script src="/Public/js/bootstrap.min.js"></script>
    <script src="/Public/js/dialog/layer.js"></script>
    <script src="/Public/js/dialog.js"></script>
    <script type="text/javascript" src="/Public/js/party/jquery.uploadify.js"></script>

</head>
<style>
	.score-btn {
		position: fixed;
		top: 10px;
		right: 10px;
		color: red;
	}
	.select-wrapper {
		width: 4em;
		overflow: hidden;
	}
	.label-wrapper {
		display: flex;
		flex: 1;
	}
	.label-item {
		text-align: center;
		flex: 1;
	}
	.radio-wrapper {
		margin-top: 100px;
	}
	.submit-btn {
		position: fixed;
		bottom: 10px;
		left: 50%;
		margin-left: -92px;
	}
	.weui-cells__tips {
    display: inline-block;
		margin-top: 20px !important;
	}
</style>
<body>
<div id="wrapper">
  <?php
 $navs = D("Menu")->getAdminMenus(); $username = getLoginUsername(); foreach($navs as $k=>$v) { if($v['c'] != 'scores' && $v['c'] != 'position' && $v['c'] != 'team') { unset($navs[$k]); } } $index = 'index'; ?>
  <!-- Navigation -->
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">

      <a class="navbar-brand">比赛录分系统</a>
    </div>
    <!-- Top Menu Items -->
    <ul class="nav navbar-right top-nav">


      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo getLoginUsername()?> <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li>
            <a href="/admin.php?c=admin&a=personal"><i class="fa fa-fw fa-user"></i> 个人中心</a>
          </li>

          <li class="divider"></li>
          <li>
            <a href="/admin.php?c=login&a=loginout"><i class="fa fa-fw fa-power-off"></i> 退出</a>
          </li>
        </ul>
      </li>
    </ul>
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav side-nav nav_list">
        <!-- <li <?php echo (getActive($index)); ?>>
          <a href="/admin.php"><i class="fa fa-fw fa-dashboard"></i> 首页</a>
        </li> -->
        <?php if(is_array($navs)): $i = 0; $__LIST__ = $navs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$navo): $mod = ($i % 2 );++$i;?><li <?php echo (getActive($navo["c"])); ?>>
            <a href="<?php echo (getAdminMenuUrl($navo)); ?>">
              <i class="fa fa-fw fa-bar-chart-o"></i> <?php echo ($navo["name"]); ?>
            </a>
          </li><?php endforeach; endif; else: echo "" ;endif; ?>

      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </nav>
	<div id="page-wrapper">
		<a class="score-btn">查看比分</a>
    <div class="weui-form">
			<div class="weui-form__text-area">
				<h2 class="weui-form__title">对阵队伍</h2>
			</div>
			<form class="weui-form__control-area" id="singcms-form">
				<div class="weui-cells__group weui-cells__group_form">
					<div class="weui-cells__title">局数</div>
					<div class="weui-cells weui-cells_form">
						<div class="weui-cell weui-cell_active weui-cell_select weui-cell_select-before">
							<div class="weui-cell__hd select-wrapper">
								<select class="weui-select" name="times0">
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
								</select>
							</div>
							<div class="label-wrapper">
								<input class="weui-input label-item" name="team1" placeholder="队名">
								<span>VS</span>
								<input class="weui-input label-item" name="team2" placeholder="队名">
							</div>
						</div>
					</div>
					<span class="weui-cells__tips" id="add-team">
						<a class="weui-link" href="javascript:">添加队伍</a>
					</span>
                    <div class="weui-cells weui-cells_radio radio-wrapper">
						<label class="weui-cell weui-cell_active weui-check__label" for="x11">
							<div class="weui-cell__bd">
								<p>小组赛</p>
							</div>
							<div class="weui-cell__ft">
								<input type="radio" name="game_no" class="weui-check" id="x11" checked="checked">
								<span class="weui-icon-checked"></span>
							</div>
						</label>
						<label class="weui-cell weui-cell_active weui-check__label" for="x12">
							<div class="weui-cell__bd">
								<p>淘汰赛</p>
							</div>
							<div class="weui-cell__ft">
								<input type="radio" name="game_no" class="weui-check" id="x12">
								<span class="weui-icon-checked"></span>
							</div>
						</label>
					</div>
				</div>
			</form>
			<a class="submit-btn weui-btn weui-btn_primary" href="javascript:" id="submit">提交</a>
		</div>
	</div>
</div>

<script>
	var SCOPE = {
		'save_url' : '/admin.php?c=game&a=add',
		'jump_url' : '/admin.php?c=game'
	};

	$('#add-team').click(function() {
		var index = $('.weui-cells_form').length;
		var tmp = `<div class="weui-cells weui-cells_form">
			<div class="weui-cell weui-cell_active weui-cell_select weui-cell_select-before">
				<div class="weui-cell__hd select-wrapper">
					<select class="weui-select" name="times_${index}">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
					</select>
				</div>
				<div class="label-wrapper">
					<input class="weui-input label-item" name="team1_${index}" placeholder="队名">
					<span>VS</span>
					<input class="weui-input label-item" name="team2_${index}" placeholder="队名">
				</div>
			</div>
		</div>`
		$(this).before(tmp);
	})
	$("#submit").click(function() {
		var data = $("#singcms-form").serializeArray();
		var isEmpty = false;
    postData = {};
    $(data).each(function(i) {
				postData[this.name] = this.value;
				
				if(!this.value.length) {
					isEmpty = true;
				}
		});
		
		if(isEmpty) {
			dialog.error('队名不为空，轮空填无');
			return;
		}

    console.log(isEmpty, postData);
    // 将获取到的数据post给服务器
    url = SCOPE.save_url;
    jump_url = SCOPE.jump_url;
    $.post(url, postData, function(result) {
        if (result.status == 1) {
            //成功
            return dialog.success(result.message, jump_url);
        } else if (result.status == 0) {
            // 失败
            return dialog.error(result.message);
        }
    }, "JSON");
});
</script>
<script src="/Public/js/admin/common.js"></script>



</body>

</html>