<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TP-CMS后台管理平台</title>
    <link href="/Public/css/weui.min.css" rel="stylesheet">

    <link href="/Public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Public/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="/Public/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/Public/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/css/sing/common.css" />
    <link rel="stylesheet" href="/Public/css/party/bootstrap-switch.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/party/uploadify.css">

    <!-- jQuery -->
    <script src="/Public/js/jquery.js"></script>
    <script src="/Public/js/bootstrap.min.js"></script>
    <script src="/Public/js/dialog/layer.js"></script>
    <script src="/Public/js/dialog.js"></script>
    <script type="text/javascript" src="/Public/js/party/jquery.uploadify.js"></script>

</head>
<body>
<div id="wrapper">

    <?php
 $navs = D("Menu")->getAdminMenus(); $username = getLoginUsername(); foreach($navs as $k=>$v) { if($v['c'] != 'scores' && $v['c'] != 'position' && $v['c'] != 'team') { unset($navs[$k]); } } $index = 'index'; ?>
  <!-- Navigation -->
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">

      <a class="navbar-brand">比赛录分系统</a>
    </div>
    <!-- Top Menu Items -->
    <ul class="nav navbar-right top-nav">


      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo getLoginUsername()?> <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li>
            <a href="/admin.php?c=admin&a=personal"><i class="fa fa-fw fa-user"></i> 个人中心</a>
          </li>

          <li class="divider"></li>
          <li>
            <a href="/admin.php?c=login&a=loginout"><i class="fa fa-fw fa-power-off"></i> 退出</a>
          </li>
        </ul>
      </li>
    </ul>
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav side-nav nav_list">
        <!-- <li <?php echo (getActive($index)); ?>>
          <a href="/admin.php"><i class="fa fa-fw fa-dashboard"></i> 首页</a>
        </li> -->
        <?php if(is_array($navs)): $i = 0; $__LIST__ = $navs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$navo): $mod = ($i % 2 );++$i;?><li <?php echo (getActive($navo["c"])); ?>>
            <a href="<?php echo (getAdminMenuUrl($navo)); ?>">
              <i class="fa fa-fw fa-bar-chart-o"></i> <?php echo ($navo["name"]); ?>
            </a>
          </li><?php endforeach; endif; else: echo "" ;endif; ?>

      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </nav>
<div id="page-wrapper">
    <div class="weui-form">
        <div class="weui-form__text-area">
            <h2 class="weui-form__title">成绩录入/查看</h2>
        </div>
        <div class="weui-form__control-area">
            <div class="weui-cells__group weui-cells__group_form">
                <form class="weui-cells weui-cells_form" id="singcms-form">
                    <div class="weui-cell weui-cell_active" id="js_cell">
                        <div class="weui-cell__hd">
                            <label for="" class="weui-label">队名</label>
                        </div>
                        <div class="weui-cell__bd">
                            <input name="team_name" class="weui-input" autofocus="" type="text" placeholder="请输入"" maxlength="16">
                        </div>
                    </div>
                    <div class="weui-cell weui-cell_active weui-cell_select weui-cell_select-after game-select-wapper">
                        <div class="weui-cell__hd">
                            <label for="" class="weui-label">赛制</label>
                        </div>
                        <div class="weui-cell__bd">
                            <select class="weui-select" name="game_no">
                                <option value="0"><div class="select-item">小组赛</div></option>
                                <option value="16"><div>淘汰赛 - 十六进八</div></option>
                                <option value="8"><div>淘汰赛 - 八进四</div></option>
                                <option value="4"><div>淘汰赛 - 四进二</div></option>
                                <option value="2"><div>淘汰赛 - 二进一</div></option>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
        <div class="weui-form__opr-area">
            <a class="weui-btn weui-btn_primary" href="javascript:" id="button-submit">确认</a>
        </div>
    </div>
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<script>
var SCOPE = {
    'save_url': '/admin.php?c=team&a=confirm',
    'jump_url': '/admin.php?c=team&a=view',
};

$("#button-submit").click(function() {
    var data = $("#singcms-form").serializeArray();
    postData = {};
    $(data).each(function(i) {
        postData[this.name] = this.value;
    });
    $.post(SCOPE.save_url, postData, function(result) {
        var status = result.status;
        if (status == 1) {
            var team_name = result.data[0];
            var game_no = result.data[1].no;
            var teams_list = result.data[1].teams.split(';');
            var final_list = [];
            teams_list.forEach(function(item) {
                var item = item.split(',');
                if(item.includes(team_name)) {
                    item[0] === team_name ? final_list.push(item[1] + ',' + item[2])
                        : final_list.push(item[0] + ',' + item[2]);
                }
            })

            // 失败
            if(!final_list.length) {
                return dialog.error(result.message);
            }

            window.location.href = SCOPE.jump_url + 
            '&game_no='+ game_no + 
            '&game_name='+ game_no + 
            '&team_name=' + result.data[0] + 
            '&team_info=' + final_list.join(';'); 
        } else if (status == 0) {
            // 失败
            return dialog.error(result.message);
        }
    }, "JSON");
});
</script>
<script src="/Public/js/admin/common.js"></script>



</body>

</html>