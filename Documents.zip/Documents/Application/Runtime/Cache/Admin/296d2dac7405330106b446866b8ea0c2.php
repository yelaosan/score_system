<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>TP-CMS后台管理平台</title>
    <link href="/Public/css/weui.min.css" rel="stylesheet">

    <link href="/Public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="/Public/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="/Public/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="/Public/css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/css/sing/common.css" />
    <link rel="stylesheet" href="/Public/css/party/bootstrap-switch.css" />
    <link rel="stylesheet" type="text/css" href="/Public/css/party/uploadify.css">

    <!-- jQuery -->
    <script src="/Public/js/jquery.js"></script>
    <script src="/Public/js/bootstrap.min.js"></script>
    <script src="/Public/js/dialog/layer.js"></script>
    <script src="/Public/js/dialog.js"></script>
    <script type="text/javascript" src="/Public/js/party/jquery.uploadify.js"></script>

</head>
<style>
	.title-desc {
		color: red;
	}
	.title-wrapper {
		display: flex;
	}
	.game-num {
		width: 2em;
	}
	.label-wrapper {
		display: flex;
		flex: 1;
	}
	.label-item {
		text-align: center;
		flex: 1;
	}
	.win-item {
		background-color: greenyellow;
	}
</style>
<body>
<div id="wrapper">

    <?php
 $navs = D("Menu")->getAdminMenus(); $username = getLoginUsername(); foreach($navs as $k=>$v) { if($v['c'] != 'scores' && $v['c'] != 'position' && $v['c'] != 'team') { unset($navs[$k]); } } $index = 'index'; ?>
  <!-- Navigation -->
  <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">

      <a class="navbar-brand">比赛录分系统</a>
    </div>
    <!-- Top Menu Items -->
    <ul class="nav navbar-right top-nav">


      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo getLoginUsername()?> <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li>
            <a href="/admin.php?c=admin&a=personal"><i class="fa fa-fw fa-user"></i> 个人中心</a>
          </li>

          <li class="divider"></li>
          <li>
            <a href="/admin.php?c=login&a=loginout"><i class="fa fa-fw fa-power-off"></i> 退出</a>
          </li>
        </ul>
      </li>
    </ul>
    <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav side-nav nav_list">
        <!-- <li <?php echo (getActive($index)); ?>>
          <a href="/admin.php"><i class="fa fa-fw fa-dashboard"></i> 首页</a>
        </li> -->
        <?php if(is_array($navs)): $i = 0; $__LIST__ = $navs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$navo): $mod = ($i % 2 );++$i;?><li <?php echo (getActive($navo["c"])); ?>>
            <a href="<?php echo (getAdminMenuUrl($navo)); ?>">
              <i class="fa fa-fw fa-bar-chart-o"></i> <?php echo ($navo["name"]); ?>
            </a>
          </li><?php endforeach; endif; else: echo "" ;endif; ?>

      </ul>
    </div>
    <!-- /.navbar-collapse -->
  </nav>
<div id="page-wrapper">

	<div class="weui-form">
		<div class="weui-form__text-area">
			<h2 class="weui-form__title">
				<span><?php echo ($game_name); ?> - </span> 
				<?php echo ($team_name); ?>的成绩面板
			</h2>
			<div class="weui-form__desc title-desc">请谨慎录入，录入错误请联系管理员</div>
		</div>
		<form class="weui-form__control-area" id="singcms-form">
			<?php if(is_array($team_info)): $i = 0; $__LIST__ = $team_info;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$team_info): $mod = ($i % 2 );++$i;?><div class="weui-cells__group weui-cells__group_form">
					<div class="weui-cells__title">
						<div class="weui-cell__hd">VS <?php echo ($team_info[0]); ?></div>
					</div>
					<div class="weui-cells weui-cells_form">
						<div class="weui-cell weui-cell_active">
							<div class="weui-cell__hd game-num">
								<label class="weui-label">局数1</label>
							</div>
							<div class="label-wrapper">
								<input name="<?php echo ($team_info[0]); ?>_game1_score1" class="weui-input label-item" placeholder="分数">
								<span>VS</span>
								<input name="<?php echo ($team_info[0]); ?>_game1_score2" class="weui-input label-item" placeholder="分数">
							</div>
						</div>
					</div>
					<?php if($team_info[1] == 3): ?><div class="weui-cells weui-cells_form">
							<div class="weui-cell weui-cell_active">
								<div class="weui-cell__hd game-num">
									<label class="weui-label">局数2</label>
								</div>
								<div class="label-wrapper">
									<input name="<?php echo ($team_info[0]); ?>_game2_score1" class="weui-input label-item" placeholder="分数">
									<span>VS</span>
									<input name="<?php echo ($team_info[0]); ?>_game2_score2" class="weui-input label-item" placeholder="分数">
								</div>
							</div>
						</div><?php endif; ?>
					<?php if($team_info[1] == 3): ?><div class="weui-cells weui-cells_form">
							<div class="weui-cell weui-cell_active">
								<div class="weui-cell__hd game-num">
									<label class="weui-label">局数3</label>
								</div>
								<div class="label-wrapper">
									<input name="<?php echo ($team_info[0]); ?>_game3_score1" class="weui-input label-item" placeholder="分数">
									<span>VS</span>
									<input name="<?php echo ($team_info[0]); ?>_game3_score2" class="weui-input label-item" placeholder="分数">
								</div>
							</div>
						</div><?php endif; ?>
				</div><?php endforeach; endif; else: echo "" ;endif; ?>
		</form>
		<div class="weui-form__opr-area">
			<a class="weui-btn weui-btn_primary" href="javascript:" id="button-submit">提交</a>
		</div>
	</div>

</div>
<!-- /#page-wrapper -->

</div>
<script>
	var SCOPE = {
		'save_url' : '/admin.php?c=team&a=submit',
	};
	var game_no = <?php echo ($game_no); ?>;
	var team_name = <?php echo ($team_name); ?>;

	$("#button-submit").click(function() {
		var data = $("#singcms-form").serializeArray();
		var isEmpty = false;
		var postData = {};
		var competitors = {};
    $(data).each(function(i) {
				postData[this.name] = this.value;

				if(competitors[this.name.split('_')[0]]) {
					competitors[this.name.split('_')[0]].push(this.value);
				}else {
					competitors[this.name.split('_')[0]] = [this.value];
				}
				if(!this.value.length) {
					isEmpty = true;
				}
		});

		// if(isEmpty) {
		// 	dialog.error('成绩不为空，轮空填0');
		// 	return;
		// }

		var dealData = [];
		for(var key in competitors) {
			dealData.push({
				name: team_name,
				game_no: game_no,
				score: competitors[key].join(';'),
				competitor: key
			})
		}
		console.log(dealData);
    $.post(SCOPE.save_url, {data: JSON.stringify(dealData)}, function(result) {
        var status = result.status;
        if (status == 1) {
					// 失败
					return dialog.success(result.message);
        } else if (status == 0) {
					return dialog.error(result.message);
        }
    }, "JSON");
});
</script>
<!-- /#wrapper -->
<script type="text/javascript" src="/Public/js/admin/form.js"></script>
<script src="/Public/js/admin/common.js"></script>



</body>

</html>