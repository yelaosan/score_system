<?php
return array(
	//'配置项'=>'配置值'
	'app_trace' =>  true,
	// Trace信息
	'trace'     =>  [
			//支持Html,Console
			'type'  =>  'html',
	] 
);