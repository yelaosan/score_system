<?php
namespace Admin\Controller;
use Think\Controller;

class TeamController extends CommonController{
    public function index(){
        $this->display();
    }

    public function view(){
        $this->assign('game_name',$_GET['game_name']);
        $this->assign('game_no',$_GET['game_no']);
        $this->assign('team_name',$_GET['team_name']);
        $arr = explode(";", $_GET['team_info']);
        $list = [];
        foreach($arr as $key => $value){
            array_push($list, explode(",", $value));
        }
        $this->assign('team_info',$list);
        return $this->display('view');
    }

    public function confirm() {
        $team_name = $_POST['team_name'];
        $game_no = $_POST['game_no'];
        if(empty($team_name)){
            return returnJson(0,'请输入队名');
        }

        $team=M('Game');
        $res = $team->where("no = $game_no and teams like '%%$team_name%%'")->select();

        if(empty($res)) {
            return returnJson(0,'暂无比赛记录，请联系管理员');
        }

        returnJson(1, '成功', array($team_name, $res[0]));
    }

    public function submit() {
        try{
            $data = json_decode($_POST['data']);
            $id=D('Team')->addAll($data);
            if($id){
                return jsonResult(1,'更新成功',$id);
            }
            return jsonResult(0,'更新失败',$id);
        }catch(Exception $e){
            return jsonResult(0,$e->getMessage());
        }
        return jsonResult(0,'更新失败',$newsId);
    }
}
?>