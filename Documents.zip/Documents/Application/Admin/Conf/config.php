<?php
return array(
    'TITLE_FONT_COLOR'=>array(
        '#5674ed'=>'蓝色',
        '#ed568b'=>'红色'
    ),
    'COPY_FROM'=>array(
        0=>'本站',
        0=>'新浪网',
        0=>'央视网',
        0=>'网易',
        0=>'搜狐',
    ),
    'WEB_ROOT'=>'',
    //'配置项'=>'配置值'
	'TMPL_CACHE_ON' => false,//禁止模板编译缓存
    'HTML_CACHE_ON' => false,//禁止静态缓存
    'app_trace' =>  true,
    // Trace信息
    'trace'     =>  [
        //支持Html,Console
        'type'  =>  'html',
    ] 
);