<?php 
phpinfo(); 
?>